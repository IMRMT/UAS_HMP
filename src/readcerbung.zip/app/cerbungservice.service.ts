import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CerbungserviceService {

  cerbungs = [
    {
      name: "Rahasia Terkunci di Perpustakaan Kuno",
      url: "https://cdn0-production-images-kly.akamaized.net/PQSxrArjnGsvtGXt58xYi5NRTTU=/1200x675/smart/filters:quality(75):strip_icc():format(jpeg)/kly-media-production/medias/1017658/original/035927600_1444628523-kpl-640x386.jpg",
      paragraf : '"Rahasia Terkunci di Perpustakaan Kuno" mengisahkan tentang seorang mahasiswa bernama Alex yang secara tak sengaja menemukan sebuah buku kuno yang misterius di perpustakaan universitasnya.',
      genre : "Aksi"

    },
    {
      name: "Rahasia banteng merah",
      url: "https://asset.kompas.com/crops/gPeOWFA3DUFaCuYq0NhrzsdXB7E=/0x0:779x519/750x500/data/photo/2021/10/15/61698c7aece86.jpg",
      paragraf : '"merah adalah kunci kemenangan.',
      genre : "Horror"
    },
    {
      name: "Manusia setengah salmon",
      url: "https://assets.pikiran-rakyat.com/crop/0x0:0x0/x/photo/2021/11/29/792355515.jpg",
      paragraf : '"Manusia dengan insang salmon.',
      genre : "Kocak",
    }
  ]
  constructor() { }
  addCerbung(c_name: string, c_url: string, c_paragraf: string, c_genre: string) {
    this.cerbungs.push({
      name: c_name,
      url: c_url,
      paragraf: c_paragraf,
      genre: c_genre
    })
  }
}
