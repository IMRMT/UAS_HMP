import { Component, OnInit } from '@angular/core';
import { CerbungserviceService } from '../cerbungservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-createcerbung',
  templateUrl: './createcerbung.page.html',
  styleUrls: ['./createcerbung.page.scss'],
})
export class CreatecerbungPage implements OnInit {

  alertButtons = "OK"
  new_name = ""
  new_url = ""
  new_para = ""
  new_genre=""
  constructor(private cerbungservice:CerbungserviceService, private router:Router) { }

  ngOnInit() {
  }

  submitCerbung() {
    this.cerbungservice.addCerbung(this.new_name, this.new_url, this.new_para, this.new_genre)
    this.new_name=""
    this.new_url=""
    this.new_para=""
    this.new_genre=""
    this.router.navigate(['/home']); 
  }

}
