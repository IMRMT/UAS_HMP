import { Component, OnInit } from '@angular/core';
import { CerbungserviceService } from '../cerbungservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-createcerbung',
  templateUrl: './createcerbung.page.html',
  styleUrls: ['./createcerbung.page.scss'],
})
export class CreatecerbungPage implements OnInit {

  jenistampilan = "first"
  alertButtons = "OK"
  c_title = ""
  c_desc = ""
  c_url = ""
  c_genre=""
  c_access = ""
  c_paragraf = ""
  arr_genre:string[] = []

  characterCount: number = 0;
  agreedToTerms: boolean = false;
  constructor(private cerbungservice:CerbungserviceService, private router:Router) { }

  ngOnInit() {
    this.arr_genre = ["kocak","horror","aksi"]
  }

  submitCerbung() {
    this.cerbungservice.addCerbung(
      this.c_title, 
      this.c_desc, 
      this.c_url, 
      this.c_genre, 
      this.c_access, 
      this.c_paragraf)
    this.router.navigate(['/home']); 
  }

  nextSection(section: string) {
    this.jenistampilan = section;
  }

  prevSection(section: string) {
    this.jenistampilan = section;
  }

  countCharacters(event: any) {
    this.characterCount = event.target.value.length;
  }

  publishCerbung() {
    if (this.agreedToTerms) {
      this.cerbungservice.addCerbung(this.c_title, this.c_desc, this.c_url, this.c_genre, this.c_access, this.c_paragraf);
      this.router.navigate(['/home']);
    }
  }

}
